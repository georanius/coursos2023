joker, November 2021

This zip folder contains (true) data obtained from ice core thin sections.
The data was acquired by Johanna Kerch, johanna.kerch@uni-goettingen.de using the open-source software IMA.
